//
//  ViewController.swift
//  slider_demo
//
//  Created by MAC on 31/05/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let step:Float = 20

    @IBOutlet weak var lb1: UILabel!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
        let myslider = UISlider()
        myslider.frame = CGRect(x: 0, y: 0, width: 200, height: 20)
        myslider.center = self.view.center
        myslider.minimumValue = 0
        myslider.maximumValue = 100
        myslider.isContinuous = false
        myslider.thumbTintColor = UIColor.green
        myslider.minimumTrackTintColor = UIColor.red
        myslider.maximumTrackTintColor = UIColor.yellow
        myslider.addTarget(self, action: #selector(self.sildervalue(_:)), for: .valueChanged)
        
        view.addSubview(myslider)
        
        UIView.animate(withDuration: 0.8)
        {
            myslider.setValue(20.0, animated: true)
        }
        self.view = view
        
        let myslider1 = UISlider()
        myslider1.frame = CGRect(x: 80, y: 400, width: 200, height: 20)
        myslider1.transform = CGAffineTransform(scaleX: 1.2, y: 2.0)
       //myslider1.center = self.view.center
        myslider1.minimumValue = 0
        myslider1.maximumValue = 100
        
        myslider1.addTarget(self, action: #selector(self.slidervaluechanged(_:)), for: .valueChanged)
        view.addSubview(myslider1)
    }
    @IBOutlet weak var sss: UISlider!
    
    @objc func slidervaluechanged(_ sender: UISlider)
    {
        let v1 = round(sender.value)
        sender.value = v1
        lb1.text = "score is "+Int(sender.value).description
    }
    
    @objc func sildervalue(_ sender:UISlider!)
    {
        print("slider value changed")
        let roundvalue = round(sender.value / step) * step
        sender.value = roundvalue
        
        print("slider step value \(Int(roundvalue))")
        
    }
}
